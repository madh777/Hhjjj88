# php-invest
Simple PHP OOP invest project (HYIP) based on mvc
