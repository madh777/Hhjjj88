<?php

return [
	'login' => 'admin',
	'password' => '12345',
];