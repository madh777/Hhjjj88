<div class="container">
    <h1 class="mt-4 mb-3"><?php echo $title; ?></h1>
    <div class="row">
        <div class="col-lg-8 mb-4">
            <a href="/account/login" class="btn btn-primary">Перейти ко входу</a>
        </div>
    </div>
</div>