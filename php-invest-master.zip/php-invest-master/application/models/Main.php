<?php

namespace application\models;

use application\core\Model;

class Main extends Model {

}