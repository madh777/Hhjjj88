<?php

return [
	'all' => [
		'perfectmoney',
	],
	'authorize' => [
		//
	],
	'guest' => [
		//
	],
	'admin' => [
		//
	],
];