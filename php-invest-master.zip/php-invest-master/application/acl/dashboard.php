<?php

return [
	'all' => [
		//
	],
	'authorize' => [
		'tariffs',
		'invest',
		'history',
		'referrals',
	],
	'guest' => [
		//
	],
	'admin' => [
		//
	],
];