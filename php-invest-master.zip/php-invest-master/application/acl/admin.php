<?php

return [
	'all' => [
		'login',
	],
	'authorize' => [
		//
	],
	'guest' => [
		//
	],
	'admin' => [
		'withdraw',
		'tariffs',
		'history',
		'logout',
	],
];